﻿namespace FigureSquare
{
    public interface IFigure
    {
        double Square { get; }
    }
}
